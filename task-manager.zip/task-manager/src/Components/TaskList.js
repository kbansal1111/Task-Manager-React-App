import React, { useState, useEffect } from "react";

function TaskList() {
    const [tasks, setTasks] = useState(() => {
        return JSON.parse(localStorage.getItem("tasks")) || [];
      });
  const [task, setTask] = useState("");

  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

    const addTask = () => {
        if (task.trim() !== "") {
          setTasks([...tasks, { text: task, completed: false }]);
          setTask("");
        }
      };

      const deleteTask = (index) => {
        const newTasks = tasks.filter((_, i) => i !== index);
        setTasks(newTasks);
        localStorage.setItem("tasks", JSON.stringify(newTasks));
      };

      const toggleComplete = (index) => {
        const newTasks = tasks.map((t, i) =>
          i === index ? { ...t, completed: !t.completed } : t
        );
        setTasks(newTasks);
        localStorage.setItem("tasks", JSON.stringify(newTasks));
      };
    

  return (
    <div>
        <input
            type="text"
            value={task}
            onChange={(e) => setTask(e.target.value)}
        />
        <button id="add" onClick={addTask}>Add Task</button>
        <ul>
            {tasks.map((t, i) => (
        <li key={i}>
            {t.text}
      <button id="tg" onClick={() => toggleComplete(i)}>{t.completed ? "Completed" : "Complete"}</button>
      <button id="del" onClick={() => deleteTask(i)}>Delete</button>
            </li>
            ))}
        </ul>

    </div>
  )
}

export default TaskList